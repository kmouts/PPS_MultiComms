# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 12:24:42 2018

@author: kmouts
"""
import sys
sys.path.append("C:/Users/kmout/Downloads/python_lib/pyAudioAnalysis")


from pyAudioAnalysis import audioTrainTest as aT


aT.featureAndTrain(["C:/LAB/Audio_Analysis/trainingData/cat",
                    "C:/LAB/Audio_Analysis/trainingData/dog"],
                   1.0, 1.0, aT.shortTermWindow, aT.shortTermStep, "svm", "svmSMtemp", False)

aT.fileClassification("C:/LAB/Audio_Analysis/sampleData/cat_11.wav",
                      "svmSMtemp","svm")



