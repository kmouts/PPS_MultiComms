# -*- coding: utf-8 -*-
"""

"""
import numpy
import sys
sys.path.append('C:/Users/K. Moutselos/Downloads/python-lib')

from pyAudioAnalysis import audioBasicIO
from pyAudioAnalysis import audioFeatureExtraction
import matplotlib.pyplot as plt
[Fs, x] = audioBasicIO.readAudioFile("C:/LAB/trainingData/cat/cat_1.wav");

# Διάγραμμα με την κυματομορφή
timeX = numpy.arange(0, x.shape[0] / float(Fs), 1.0 / Fs)
plt.plot(timeX, x)
plt.show()

F = audioFeatureExtraction.stFeatureExtraction(x, Fs, 0.050*Fs, 0.025*Fs);
plt.subplot(2,1,1); plt.plot(F[0,:]); plt.xlabel('Frame no'); plt.ylabel('ZCR'); # plt.plot(F[0][0]) for Python 3
plt.subplot(2,1,2); plt.plot(F[1,:]); plt.xlabel('Frame no'); plt.ylabel('Energy'); # plt.plot(F[0][1]) for Python 3



plt.show()

